<x-site.layout title="Page not found" description="" nav="">
  <section class="container-page py-20">
    <p class="text-sm font-semibold uppercase tracking-widest text-brand-100">Error 404</p>
    <h1 class="mt-3 text-4xl font-bold">Page not found</h1>
    <p class="mt-3 max-w-xl text-lg text-muted">The page you asked for does not exist or has moved. Check the address, or use one of the links below.</p>
    <div class="mt-8 flex flex-wrap gap-3"><a class="btn-primary" href="{{ route('site.home') }}">Go to the home page</a><a class="btn-ghost" href="{{ route('site.shop') }}">Browse products</a></div>
  </section>
</x-site.layout>
