@php
    $links = [
        ['key' => 'shop', 'label' => 'Products', 'href' => route('site.shop')],
        ['key' => 'categories', 'label' => 'Categories', 'href' => route('site.home') . '#categories'],
        ['key' => 'how', 'label' => 'How it works', 'href' => route('site.home') . '#how'],
        ['key' => 'about', 'label' => 'About', 'href' => route('site.about')],
        ['key' => 'faq', 'label' => 'FAQ', 'href' => route('site.faq')],
        ['key' => 'contact', 'label' => 'Contact', 'href' => route('site.contact')],
    ];
    $pageTitle = $title !== '' ? $title . ' | ' . $company : $company;
    $waDigits = preg_replace('/\D/', '', (string) $whatsapp);
@endphp
<!DOCTYPE html>
<html lang="en-GB">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ $pageTitle }}</title>
  @if ($description !== '')
    <meta name="description" content="{{ $description }}">
    <meta property="og:description" content="{{ $description }}">
  @endif
  <meta property="og:title" content="{{ $pageTitle }}">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="{{ $company }}">
  <meta property="og:locale" content="en_GB">
  <meta name="theme-color" content="#05070d">
  <link rel="canonical" href="{{ url()->current() }}">
  <meta property="og:url" content="{{ url()->current() }}">
  @unless (app()->environment('production'))
    <meta name="robots" content="noindex, nofollow">
  @endunless
  <link rel="stylesheet" href="{{ asset('assets/site/css/style.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/site/css/site-extra.css') }}">
  <script>window.SITE_CONFIG = {{ Illuminate\Support\Js::from(['whatsapp' => $waDigits !== '' ? '+' . $waDigits : '']) }};</script>
  <script src="{{ asset('assets/site/js/main.js') }}" defer></script>
  <script src="{{ asset('assets/site/js/enquiry.js') }}" defer></script>
</head>
<body>
  <a href="#main" class="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-canvas">Skip to main content</a>

  <header class="site-nav sticky top-0 z-40">
    <div class="container-page flex h-16 items-center justify-between">
      <a href="{{ route('site.home') }}" class="font-display text-xl font-bold text-ink">{{ $company }}</a>
      <nav aria-label="Main" class="hidden lg:block">
        <ul class="flex gap-1">
          @foreach ($links as $link)
            <li><a class="block rounded-lg px-3 py-2 font-medium text-ink hover:bg-white/10 hover:text-white {{ $nav === $link['key'] ? 'bg-brand-50 text-brand-100' : '' }}" href="{{ $link['href'] }}" @if ($nav === $link['key']) aria-current="page" @endif>{{ $link['label'] }}</a></li>
          @endforeach
        </ul>
      </nav>
      <div class="flex items-center gap-2">
        @if (Route::has('site.enquiry'))
          <a href="{{ route('site.enquiry') }}" class="inline-flex min-h-11 items-center rounded-lg border border-line px-3 text-sm font-semibold text-ink hover:bg-white/10">Enquiry list<span data-enquiry-count></span></a>
        @endif
        <button type="button" class="grid size-11 place-items-center rounded-lg border border-line lg:hidden" data-menu-toggle aria-expanded="false" aria-controls="mobile-menu" aria-label="Menu">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
        </button>
      </div>
    </div>
    <nav id="mobile-menu" data-menu aria-label="Mobile" class="hidden border-t border-line glass-menu lg:hidden">
      <ul class="container-page py-2">
        @foreach ($links as $link)
          <li><a class="block rounded-lg px-3 py-2 font-medium text-ink hover:bg-white/10" href="{{ $link['href'] }}">{{ $link['label'] }}</a></li>
        @endforeach
      </ul>
    </nav>
  </header>

  <main id="main">{{ $slot }}</main>

  <footer class="glass-footer text-sm text-slate-300">
    <div class="container-page grid gap-8 py-12 md:grid-cols-3">
      <div>
        <p class="font-display text-xl font-bold text-white">{{ $company }}</p>
        <p class="mt-2 max-w-xs">{{ $settings['tagline'] ?? 'UK products for wholesalers and retailers in Bangladesh and other countries.' }}</p>
        <p class="mt-2"><a data-whatsapp href="{{ route('site.shop') }}" hidden class="inline-flex min-h-11 items-center font-semibold text-white underline">Chat on WhatsApp<span class="sr-only"> (opens in a new tab)</span></a></p>
      </div>
      <nav aria-label="Footer: explore">
        <h2 class="font-sans text-base font-semibold text-white">Explore</h2>
        <ul class="mt-2">
          @foreach ($links as $link)
            <li><a class="inline-block py-1.5 hover:text-white" href="{{ $link['href'] }}">{{ $link['label'] }}</a></li>
          @endforeach
        </ul>
      </nav>
    </div>
    <div class="border-t border-white/10 py-4 text-xs">
      <div class="container-page"><p>&copy; {{ date('Y') }} {{ $company }}. All rights reserved.</p></div>
    </div>
  </footer>
  <a data-whatsapp href="{{ route('site.shop') }}" hidden class="wa-float" aria-label="Chat on WhatsApp (opens in a new tab)"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.9 7L4 20l1.2-4.6A8 8 0 1 1 21 12z"/></svg></a>
</body>
</html>
