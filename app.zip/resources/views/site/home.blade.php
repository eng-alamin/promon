<x-site.layout title="" description="UK products for retailers and wholesalers in Bangladesh. Prices in pounds sterling (£). Enquire on WhatsApp." nav="">
  <section class="border-b border-line">
    <div class="container-page py-16 lg:py-24">
      <p class="text-sm font-semibold uppercase tracking-widest text-brand-100">UK Products | Bangladesh</p>
      <h1 class="mt-3 max-w-3xl text-4xl font-medium leading-tight sm:text-5xl">UK products for retailers in Bangladesh, delivered in 10 working days.</h1>
      <p class="mt-5 max-w-xl text-lg text-body">Browse the catalogue, see prices in pounds sterling (£) and send us an enquiry. There is no online checkout.</p>
      <div class="mt-8 flex flex-wrap gap-3">
        <a href="{{ route('site.shop') }}" class="btn-primary">Browse products</a>
        <a data-whatsapp href="{{ route('site.shop') }}" hidden class="btn-ghost">Chat on WhatsApp<span class="sr-only"> (opens in a new tab)</span></a>
        <a href="#how" class="btn-ghost">How it works</a>
      </div>
    </div>
  </section>

  <section id="categories" class="container-page py-16">
    <h2 class="text-3xl font-bold">Product categories</h2>
    <p class="mt-2 max-w-2xl text-muted">Pick a category to see its products and prices.</p>
    <ul class="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
      @foreach ($categories as $category)
        <li><a href="{{ route('site.shop', ['category' => $category->slug]) }}" class="glass-tile card-hover flex aspect-4/3 h-full w-full items-end p-4 font-display text-lg text-ink">{{ $category->name }}</a></li>
      @endforeach
    </ul>
  </section>

  @if ($popular->isNotEmpty())
    <section id="popular" class="container-page py-16">
      <div class="flex flex-wrap items-end justify-between gap-3">
        <h2 class="text-3xl font-bold">Popular products</h2>
        <a class="btn-ghost" href="{{ route('site.shop') }}">View all products</a>
      </div>
      <ul class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        @foreach ($popular as $product)<x-site.product-card :product="$product" />@endforeach
      </ul>
    </section>
  @endif

  @if ($newArrivals->isNotEmpty())
    <section id="new" class="container-page pb-16">
      <h2 class="text-3xl font-bold">New arrivals</h2>
      <ul class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        @foreach ($newArrivals as $product)<x-site.product-card :product="$product" />@endforeach
      </ul>
    </section>
  @endif

  <section id="how" class="border-y border-line py-16">
    <div class="container-page">
      <h2 class="text-3xl font-bold">How it works</h2>
      <ol class="mt-8 grid gap-4 md:grid-cols-3">
        @foreach ([['Browse', 'See the categories, products and prices in pounds sterling (£).'], ['Enquire', 'Tell us the products and quantities you want, on WhatsApp or through the enquiry form.'], ['Delivery', 'Products are sent from the UK to Bangladesh in about 10 working days.']] as $i => [$head, $text])
          <li class="card p-6"><span class="grid size-9 place-items-center rounded-full bg-brand-600 text-sm font-bold text-white" aria-hidden="true">{{ $i + 1 }}</span><h3 class="mt-4 text-lg">{{ $head }}</h3><p class="mt-1 text-sm text-muted">{{ $text }}</p></li>
        @endforeach
      </ol>
    </div>
  </section>
</x-site.layout>
