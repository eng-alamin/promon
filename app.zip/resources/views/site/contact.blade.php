@php
    $details = array_filter([
        'Email' => $settings['email'] ?? null,
        'Phone' => $settings['phone'] ?? null,
        'Opening hours' => $settings['working_hours'] ?? null,
    ], fn ($v) => filled($v));
    $address = $settings['address'] ?? null;
@endphp
<x-site.layout title="Contact" description="Contact {{ $company }} on WhatsApp or by email to ask about products and prices." nav="contact">
  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 class="text-4xl font-bold">Contact us</h1>
      <p class="mt-2 max-w-2xl text-muted">Message us on WhatsApp, or send an enquiry with the products you need. There is no online checkout.</p>
    </div>
  </section>
  <section class="container-page grid gap-8 py-10 lg:grid-cols-2">
    <div class="card space-y-5 p-6">
      <h2 class="text-2xl font-bold">Get in touch</h2>
      <div class="flex flex-wrap gap-3">
        <a data-whatsapp href="{{ route('site.enquiry') }}" hidden class="btn-primary min-h-11">Chat on WhatsApp<span class="sr-only"> (opens in a new tab)</span></a>
        <a class="btn-ghost min-h-11" href="{{ route('site.enquiry') }}">Send an enquiry</a>
      </div>
      @if ($details !== [] || filled($address))
        <dl class="grid grid-cols-[max-content_1fr] gap-x-6 gap-y-2 text-sm">
          @foreach ($details as $label => $value)
            <dt class="text-muted">{{ $label }}</dt><dd class="font-medium text-ink break-words">{{ $value }}</dd>
          @endforeach
          @if (filled($address))
            <dt class="text-muted">Address</dt><dd class="font-medium text-ink whitespace-pre-line break-words">{{ $address }}</dd>
          @endif
        </dl>
      @endif
    </div>
    <div class="card space-y-3 p-6">
      <h2 class="text-2xl font-bold">Before you write</h2>
      <p class="text-muted">Tell us the products, the quantities and where the goods should go. Our reply will include prices in pounds sterling (£) and delivery details.</p>
      <p><a class="underline" href="{{ route('site.faq') }}">Read the FAQ</a></p>
    </div>
  </section>
</x-site.layout>
