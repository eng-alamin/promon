@php
    $field = fn (string $name) => $errors->first($name);
    $itemErrors = collect($errors->getMessageBag()->messages())->filter(fn ($m, $k) => str_starts_with($k, 'items'))->flatten()->unique();
@endphp
<x-site.layout title="Enquiry list" description="Choose products and quantities, then send your enquiry to us. No online payment." nav="">
  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 data-enquiry-heading tabindex="-1" class="text-4xl font-bold">Enquiry list</h1>
      <p class="mt-2 max-w-2xl text-muted">Add products from the catalogue, set the quantities, then send the list to us. Nothing is ordered or paid for on this website. The list is saved in this browser only.</p>
    </div>
  </section>

  <section data-enquiry class="container-page py-10">
    <p data-enquiry-empty class="text-muted">Your enquiry list is empty. <a class="underline" href="{{ route('site.shop') }}">Browse the products</a> and choose "Add to enquiry list".</p>
    <noscript><p class="mt-4 text-muted">JavaScript is needed for the enquiry list. <a class="underline" href="{{ route('site.shop') }}">Back to products</a>.</p></noscript>

    <form data-enquiry-form method="POST" action="{{ route('site.enquiry.submit') }}" hidden class="space-y-5" novalidate>
      @csrf
      @if ($itemErrors->isNotEmpty())
        <div class="card p-4" role="alert">
          @foreach ($itemErrors as $message)<p class="text-sm font-medium text-red-300">{{ $message }}</p>@endforeach
        </div>
      @endif

      <ul data-enquiry-list class="space-y-3"></ul>

      <div class="card space-y-5 p-6">
        <h2 class="text-2xl font-bold">Your details</h2>
        <div class="grid gap-4 sm:grid-cols-2">
          <div>
            <label for="e-business" class="block font-semibold text-ink">Business name</label>
            <input id="e-business" name="business_name" type="text" value="{{ old('business_name') }}" maxlength="150" required autocomplete="organization" class="field" @if ($field('business_name')) aria-invalid="true" @endif>
            @error('business_name')<p class="mt-1 text-sm font-medium text-red-300">{{ $message }}</p>@enderror
          </div>
          <div>
            <label for="e-name" class="block font-semibold text-ink">Contact name</label>
            <input id="e-name" name="contact_name" type="text" value="{{ old('contact_name') }}" maxlength="100" required autocomplete="name" class="field" @if ($field('contact_name')) aria-invalid="true" @endif>
            @error('contact_name')<p class="mt-1 text-sm font-medium text-red-300">{{ $message }}</p>@enderror
          </div>
          <div>
            <label for="e-type" class="block font-semibold text-ink">You are a</label>
            <select id="e-type" name="type" required class="field">
              @foreach ($types as $type)
                <option value="{{ $type->value }}" @selected(old('type', 'retailer') === $type->value)>{{ $type->label() }}</option>
              @endforeach
            </select>
            @error('type')<p class="mt-1 text-sm font-medium text-red-300">{{ $message }}</p>@enderror
          </div>
          <div>
            <label for="e-email" class="block font-semibold text-ink">Email <span class="font-normal text-muted">(email, phone or WhatsApp is needed)</span></label>
            <input id="e-email" name="email" type="email" value="{{ old('email') }}" maxlength="150" autocomplete="email" class="field" @if ($field('email')) aria-invalid="true" @endif>
            @error('email')<p class="mt-1 text-sm font-medium text-red-300">{{ $message }}</p>@enderror
          </div>
          <div>
            <label for="e-phone" class="block font-semibold text-ink">Phone <span class="font-normal text-muted">(optional)</span></label>
            <input id="e-phone" name="phone" type="tel" value="{{ old('phone') }}" maxlength="30" autocomplete="tel" class="field" @if ($field('phone')) aria-invalid="true" @endif>
            @error('phone')<p class="mt-1 text-sm font-medium text-red-300">{{ $message }}</p>@enderror
          </div>
          <div>
            <label for="e-wa" class="block font-semibold text-ink">WhatsApp <span class="font-normal text-muted">(optional)</span></label>
            <input id="e-wa" name="whatsapp" type="tel" value="{{ old('whatsapp') }}" maxlength="30" class="field" @if ($field('whatsapp')) aria-invalid="true" @endif>
            @error('whatsapp')<p class="mt-1 text-sm font-medium text-red-300">{{ $message }}</p>@enderror
          </div>
          <div>
            <label for="e-city" class="block font-semibold text-ink">City <span class="font-normal text-muted">(optional)</span></label>
            <input id="e-city" name="city" type="text" value="{{ old('city') }}" maxlength="100" class="field">
          </div>
          <div>
            <label for="e-country" class="block font-semibold text-ink">Country <span class="font-normal text-muted">(optional)</span></label>
            <input id="e-country" name="country" type="text" value="{{ old('country') }}" maxlength="100" class="field">
          </div>
        </div>
        <div>
          <label for="e-message" class="block font-semibold text-ink">Message <span class="font-normal text-muted">(optional)</span></label>
          <textarea id="e-message" name="message" rows="4" maxlength="2000" class="field">{{ old('message') }}</textarea>
          @error('message')<p class="mt-1 text-sm font-medium text-red-300">{{ $message }}</p>@enderror
        </div>
        {{-- Honeypot: hidden from people, bots tend to fill it. --}}
        <div style="position:absolute;left:-9999px" aria-hidden="true">
          <label for="e-website">Leave this field empty</label>
          <input id="e-website" name="website" type="text" tabindex="-1" autocomplete="off" value="">
        </div>
        @error('website')<p class="text-sm font-medium text-red-300">{{ $message }}</p>@enderror

        <div class="flex flex-wrap gap-3">
          <button type="submit" class="btn-primary min-h-11">Send enquiry</button>
          <a data-enquiry-wa hidden class="btn-ghost min-h-11" href="{{ route('site.shop') }}">Send list on WhatsApp<span class="sr-only"> (opens in a new tab)</span></a>
          <button type="button" data-enquiry-clear class="btn-ghost min-h-11">Clear list</button>
        </div>
        <p class="text-sm text-muted">Sending on WhatsApp opens your WhatsApp app with the list typed for you. It is not saved on this website; "Send enquiry" is.</p>
      </div>
    </form>
  </section>

  <script>window.ENQUIRY_PRODUCTS_URL = {{ Illuminate\Support\Js::from(route('site.enquiry.products')) }};</script>
  <script src="{{ asset('assets/site/js/enquiry-page.js') }}" defer></script>
</x-site.layout>
