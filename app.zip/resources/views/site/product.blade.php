@php
    $facts = array_filter([
        'Category' => $product->category?->name,
        'Availability' => $product->status->label(),
        'Minimum order' => $product->moq ? (string) $product->moq : null,
        'Pack size' => $product->pack_size,
        'Brand' => $product->brand?->name,
        'Origin' => $product->origin_country,
        'Shelf life' => $product->shelf_life,
        'Bangladesh approval' => $product->bd_approval,
    ], fn ($v) => is_string($v) && trim($v) !== '');
    $image = $product->primaryImage?->url ?? $product->images->first()?->url;
    $waText = 'Hello, I would like to enquire about: ' . $product->name;
@endphp
<x-site.layout :title="$product->name" :description="\Illuminate\Support\Str::limit(strip_tags((string) $product->description), 150)" nav="shop">
  <section class="container-page py-10">
    <p class="text-sm text-muted">
      <a class="underline" href="{{ route('site.shop') }}">Products</a>
      @if ($product->category) / <a class="underline" href="{{ route('site.shop', ['category' => $product->category->slug]) }}">{{ $product->category->name }}</a>@endif
    </p>
    <h1 class="mt-2 text-4xl font-bold">{{ $product->name }}</h1>

    <div class="mt-8 grid gap-8 lg:grid-cols-2">
      <div class="card relative aspect-4/3 overflow-hidden bg-brand-50">
        <span class="grid size-full place-items-center font-display text-7xl text-brand-100" aria-hidden="true">{{ mb_substr($product->category?->name ?? $product->name, 0, 1) }}</span>
        @if ($image)
          <img src="{{ $image }}" alt="{{ $product->primaryImage?->alt_text ?: $product->name }}" class="absolute inset-0 size-full object-cover" onerror="this.remove()">
        @endif
      </div>

      <div>
        <p class="text-3xl font-bold text-ink">£{{ number_format((float) $product->price, 2) }}</p>

        <dl class="mt-6 grid grid-cols-[max-content_1fr] gap-x-6 gap-y-2 text-sm">
          @foreach ($facts as $label => $value)
            <dt class="text-muted">{{ $label }}</dt><dd class="font-medium text-ink">{{ $value }}</dd>
          @endforeach
        </dl>

        @if ($product->priceTiers->isNotEmpty())
          <table class="mt-6 w-full text-left text-sm">
            <caption class="pb-2 text-left font-semibold text-ink">Price by quantity</caption>
            <thead><tr><th scope="col" class="border-b border-line py-2 pr-4 font-semibold text-ink">Quantity</th><th scope="col" class="border-b border-line py-2 pr-4 font-semibold text-ink">Price per unit</th></tr></thead>
            <tbody>
              @foreach ($product->priceTiers as $tier)
                <tr><td class="border-b border-line py-2 pr-4">{{ $tier->min_qty }}+</td><td class="border-b border-line py-2">£{{ number_format((float) $tier->price, 2) }}</td></tr>
              @endforeach
            </tbody>
          </table>
        @endif

        @if (filled($product->description))
          <p class="mt-6 whitespace-pre-line text-body">{{ $product->description }}</p>
        @endif

        <div class="mt-8 flex flex-wrap gap-3">
          <button type="button" class="btn-primary min-h-11" data-enquiry-id="{{ $product->id }}" data-enquiry-name="{{ $product->name }}">Add to enquiry list</button>
          <a data-whatsapp data-wa-text="{{ $waText }}" href="{{ route('site.shop') }}" hidden class="btn-ghost min-h-11">Ask on WhatsApp<span class="sr-only"> (opens in a new tab)</span></a>
        </div>
      </div>
    </div>
  </section>
</x-site.layout>
