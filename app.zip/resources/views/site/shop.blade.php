<x-site.layout title="Products" description="Browse UK products by category with prices in pounds sterling (£)." nav="shop">
  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 class="text-4xl font-bold">Products</h1>
      <p class="mt-2 max-w-2xl text-muted">Browse by category. Prices are in pounds sterling (£). There is no online checkout: add products to your enquiry list or message us on WhatsApp.</p>
    </div>
  </section>
  <section class="container-page py-10">
    <form method="GET" action="{{ route('site.shop') }}" class="flex flex-wrap items-end gap-4">
      @if ($activeSlug !== '')<input type="hidden" name="category" value="{{ $activeSlug }}">@endif
      <div class="min-w-56 flex-1">
        <label for="q" class="block text-sm font-medium text-ink">Search products</label>
        <input id="q" name="q" type="search" value="{{ $term }}" maxlength="100" autocomplete="off" placeholder="Search by product name or SKU" class="field mt-1 w-full">
      </div>
      <div>
        <label for="sort" class="block text-sm font-medium text-ink">Sort by</label>
        <select id="sort" name="sort" class="field mt-1">
          @foreach (['default' => 'Default order', 'price-asc' => 'Price: low to high', 'price-desc' => 'Price: high to low', 'name-asc' => 'Name: A to Z'] as $value => $label)
            <option value="{{ $value }}" @selected($sort === $value)>{{ $label }}</option>
          @endforeach
        </select>
      </div>
      <button type="submit" class="btn-primary min-h-11">Apply</button>
    </form>

    <div role="group" aria-label="Filter by category" class="mt-6 flex flex-wrap gap-2">
      @foreach (array_merge([['slug' => '', 'name' => 'All']], $categories->map(fn ($c) => ['slug' => $c->slug, 'name' => $c->name])->all()) as $chip)
        <a href="{{ route('site.shop', array_filter(['category' => $chip['slug'], 'q' => $term, 'sort' => $sort !== 'default' ? $sort : null])) }}"
           class="rounded-full border border-white/20 bg-white/6 px-4 py-2 text-sm font-medium text-ink hover:border-white/40 {{ $activeSlug === $chip['slug'] ? 'bg-brand-50 text-brand-100' : '' }}"
           @if ($activeSlug === $chip['slug']) aria-current="true" @endif>{{ $chip['name'] }}</a>
      @endforeach
    </div>

    <p class="mt-4 text-sm text-muted" role="status">{{ $products->total() }} {{ \Illuminate\Support\Str::plural('product', $products->total()) }} found</p>

    <ul class="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      @forelse ($products as $product)
        <x-site.product-card :product="$product" />
      @empty
        <li class="text-muted sm:col-span-2 lg:col-span-4">{{ $term !== '' ? 'No products match your search. Try a different word or choose All.' : 'No products are listed in this category yet. Message us to ask about it.' }}</li>
      @endforelse
    </ul>

    <div class="mt-8">{{ $products->links('site.pagination') }}</div>
  </section>
</x-site.layout>
