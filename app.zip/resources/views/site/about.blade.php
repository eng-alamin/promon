<x-site.layout title="About us" description="Promon supplies UK products to wholesalers and retailers in Bangladesh and other countries." nav="about">
  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 class="text-4xl font-bold">About us</h1>
      <p class="mt-2 max-w-2xl text-muted">{{ $settings['tagline'] ?? 'We supply UK products to wholesalers and retailers in Bangladesh and other countries.' }}</p>
    </div>
  </section>
  <section class="container-page grid gap-8 py-10 lg:grid-cols-2">
    <div class="card space-y-3 p-6">
      <h2 class="text-2xl font-bold">What we supply</h2>
      <p class="text-muted">We work in {{ $categories->count() }} product categories. Pick a category to see its products.</p>
      <ul class="flex flex-wrap gap-2">
        @foreach ($categories as $category)
          <li><a class="inline-block rounded-full border border-white/20 bg-white/6 px-4 py-2 text-sm font-medium text-ink hover:border-white/40" href="{{ route('site.shop', ['category' => $category->slug]) }}">{{ $category->name }}</a></li>
        @endforeach
      </ul>
    </div>
    <div class="space-y-4">
      <div class="card p-6"><h2 class="text-2xl font-bold">Prices in pounds</h2><p class="mt-2 text-muted">Every price on the site is in pounds sterling (£ GBP).</p></div>
      @if (filled($settings['delivery_time'] ?? null))
        <div class="card p-6"><h2 class="text-2xl font-bold">Delivery</h2><p class="mt-2 text-muted">{{ $settings['delivery_time'] }}</p></div>
      @endif
      <div class="card p-6"><h2 class="text-2xl font-bold">Have a question?</h2><p class="mt-2 text-muted">Check the FAQ first, or message us.</p>
        <div class="mt-4 flex flex-wrap gap-3"><a class="btn-ghost" href="{{ route('site.faq') }}">Read the FAQ</a><a class="btn-primary" href="{{ route('site.contact') }}">Contact us</a></div>
      </div>
    </div>
  </section>
</x-site.layout>
