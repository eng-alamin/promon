<x-site.layout title="Enquiry sent" description="Your enquiry has been received." nav="">
  <section class="container-page py-16">
    <h1 class="text-4xl font-bold">Thank you, your enquiry is sent</h1>
    <p class="mt-4 max-w-2xl text-body">Your reference is <strong class="text-ink">{{ $reference }}</strong>. We will reply with prices and delivery details using the contact details you gave. Nothing has been ordered or charged.</p>
    <div class="mt-8 flex flex-wrap gap-3">
      <a href="{{ route('site.shop') }}" class="btn-primary">Back to products</a>
    </div>
  </section>
  <script>
    // The enquiry is saved on the server, so the list in this browser can be emptied.
    document.addEventListener('DOMContentLoaded', function () {
      if (window.PROMON && window.PROMON.enquiry) { window.PROMON.enquiry.clear(); }
    });
  </script>
</x-site.layout>
