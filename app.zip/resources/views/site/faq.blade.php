<x-site.layout title="FAQ" description="Quick answers about prices, ordering, delivery and getting in touch." nav="faq">
  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 class="text-4xl font-bold">Frequently asked questions</h1>
      <p class="mt-2 max-w-2xl text-muted">Quick answers about prices, ordering, delivery and getting in touch. Open a question to read the answer.</p>
    </div>
  </section>
  <section class="container-page py-10">
    <div class="max-w-3xl space-y-3">
      @forelse ($faqs as $faq)
        <details name="faq" class="group card">
          <summary class="flex cursor-pointer list-none items-center justify-between gap-4 p-5 font-semibold text-ink [&::-webkit-details-marker]:hidden"><span>{{ $faq->question }}</span><svg class="size-5 shrink-0 text-brand-100 transition-transform duration-200 group-open:rotate-180" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></summary>
          <div class="px-5 pb-5 leading-relaxed text-muted whitespace-pre-line break-words">{{ $faq->answer }}</div>
        </details>
      @empty
        <p class="text-muted">No questions have been added yet. Please <a class="underline" href="{{ route('site.contact') }}">contact us</a>.</p>
      @endforelse
    </div>
    <p class="mt-8 text-muted">Cannot find your answer? <a class="underline" href="{{ route('site.contact') }}">Contact us</a>.</p>
  </section>
</x-site.layout>
