@if ($paginator->hasPages())
  <nav aria-label="Pagination" class="flex flex-wrap items-center justify-between gap-3">
    @if ($paginator->onFirstPage())
      <span class="btn-ghost min-h-11 opacity-50" aria-disabled="true">Previous</span>
    @else
      <a class="btn-ghost min-h-11" href="{{ $paginator->previousPageUrl() }}" rel="prev">Previous</a>
    @endif
    <p class="text-sm text-muted">Page {{ $paginator->currentPage() }} of {{ $paginator->lastPage() }}</p>
    @if ($paginator->hasMorePages())
      <a class="btn-ghost min-h-11" href="{{ $paginator->nextPageUrl() }}" rel="next">Next</a>
    @else
      <span class="btn-ghost min-h-11 opacity-50" aria-disabled="true">Next</span>
    @endif
  </nav>
@endif
