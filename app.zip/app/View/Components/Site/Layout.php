<?php

declare(strict_types=1);

namespace App\View\Components\Site;

use App\Services\Admin\SettingService;
use Illuminate\Contracts\View\View;
use Illuminate\View\Component;

/**
 * Public page frame. Reads the company settings once so every page shows the
 * company name, tagline and WhatsApp number from the admin Settings page.
 */
class Layout extends Component
{
    /** @var array<string, string|null> */
    public array $settings;

    public string $company;

    public ?string $whatsapp;

    public function __construct(
        SettingService $settings,
        public string $title = '',
        public string $description = '',
        public string $nav = '',
    ) {
        $this->settings = $settings->all();
        $this->company = $this->settings['company_name'] ?? 'Promon';
        $this->whatsapp = $this->settings['whatsapp'] ?? null;
    }

    public function render(): View
    {
        return view('components.site.layout');
    }
}
