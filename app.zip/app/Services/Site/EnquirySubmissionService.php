<?php

declare(strict_types=1);

namespace App\Services\Site;

use App\Enums\EnquiryChannel;
use App\Enums\EnquiryStatus;
use App\Models\Customer;
use App\Models\Enquiry;
use App\Models\EnquiryItem;
use App\Models\Product;
use App\Services\PriceResolver;
use Illuminate\Support\Facades\DB;

/**
 * Saves an enquiry sent from the public website. The unit price of each item is
 * saved as a snapshot, the same way as for enquiries typed in by staff.
 */
class EnquirySubmissionService
{
    public function __construct(
        private readonly PriceResolver $prices,
        private readonly CatalogueService $catalogue,
    ) {
    }

    /**
     * @param  array<string, mixed>  $customer  business_name, contact_name, email, phone, whatsapp, city, country, type
     * @param  array<int, array{product_id: int|string, quantity: int|string}>  $items
     */
    public function submit(array $customer, array $items, ?string $message): Enquiry
    {
        $products = $this->catalogue
            ->findVisible(array_map(fn (array $i): int => (int) $i['product_id'], $items))
            ->keyBy('id');

        return DB::transaction(function () use ($customer, $items, $message, $products): Enquiry {
            $enquiry = Enquiry::create([
                'customer_id' => $this->customer($customer)->id,
                'channel' => EnquiryChannel::Form,
                'status' => EnquiryStatus::New,
                'message' => $message,
            ]);

            foreach ($items as $item) {
                /** @var Product $product */
                $product = $products->get((int) $item['product_id']);
                $quantity = (int) $item['quantity'];

                EnquiryItem::create([
                    'enquiry_id' => $enquiry->id,
                    'product_id' => $product->id,
                    'quantity' => $quantity,
                    'unit_price' => $this->prices->unitPrice($product, $quantity),
                ]);
            }

            return $enquiry;
        });
    }

    /**
     * Reuse a customer with the same email (or phone/WhatsApp when there is no email).
     * An existing customer is never changed from public input; staff keep their data.
     *
     * @param  array<string, mixed>  $data
     */
    private function customer(array $data): Customer
    {
        $existing = null;

        if (! empty($data['email'])) {
            $existing = Customer::where('email', $data['email'])->first();
        } else {
            foreach (['whatsapp', 'phone'] as $field) {
                if (! empty($data[$field])) {
                    $existing = Customer::where($field, $data[$field])->first();
                    break;
                }
            }
        }

        return $existing ?? Customer::create($data);
    }
}
