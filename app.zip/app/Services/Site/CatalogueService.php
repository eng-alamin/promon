<?php

declare(strict_types=1);

namespace App\Services\Site;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;

/**
 * Read-only queries for the public site. Only active products in active categories are returned.
 */
class CatalogueService
{
    public const SORTS = ['default', 'price-asc', 'price-desc', 'name-asc'];

    public const PER_PAGE = 12;

    /** @return Collection<int, Category> */
    public function categories(): Collection
    {
        return Category::active()->ordered()->get();
    }

    /** @return Collection<int, Product> */
    public function popular(int $limit = 8): Collection
    {
        return $this->visible()->popular()->orderBy('sort_order')->limit($limit)->get();
    }

    /** @return Collection<int, Product> */
    public function newArrivals(int $limit = 8): Collection
    {
        return $this->visible()->newArrivals()->latest('id')->limit($limit)->get();
    }

    public function search(?string $categorySlug, ?string $term, string $sort): LengthAwarePaginator
    {
        $query = $this->visible();

        if ($categorySlug !== null && $categorySlug !== '') {
            $query->whereHas('category', fn (Builder $q) => $q->where('slug', $categorySlug));
        }

        $term = trim((string) $term);
        if ($term !== '') {
            // Escape LIKE wildcards so "100%" is searched as text.
            $like = '%' . addcslashes($term, '\\%_') . '%';
            $query->where(fn (Builder $q) => $q->where('name', 'like', $like)->orWhere('sku', 'like', $like));
        }

        match ($sort) {
            'price-asc' => $query->orderBy('price')->orderBy('name'),
            'price-desc' => $query->orderByDesc('price')->orderBy('name'),
            'name-asc' => $query->orderBy('name'),
            default => $query->orderBy('sort_order')->orderBy('name'),
        };

        return $query->paginate(self::PER_PAGE)->withQueryString();
    }

    public function findBySlug(string $slug): Product
    {
        return $this->visible()
            ->with(['brand', 'images', 'priceTiers'])
            ->where('slug', $slug)
            ->firstOrFail();
    }

    /**
     * Visible products for a list of ids (enquiry list, enquiry validation).
     *
     * @param  array<int, int>  $ids
     * @return Collection<int, Product>
     */
    public function findVisible(array $ids): Collection
    {
        if ($ids === []) {
            return new Collection();
        }

        return $this->visible()->whereIn('id', $ids)->get();
    }

    /** @return Collection<int, Product> slug and updated_at only, for the sitemap */
    public function sitemapProducts(): Collection
    {
        return $this->visible()->setEagerLoads([])->get(['slug', 'updated_at']);
    }

    /** @return Builder<Product> */
    private function visible(): Builder
    {
        return Product::query()
            ->active()
            ->whereHas('category', fn (Builder $q) => $q->where('is_active', true))
            ->with(['category', 'primaryImage']);
    }
}
