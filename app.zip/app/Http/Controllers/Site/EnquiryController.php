<?php

declare(strict_types=1);

namespace App\Http\Controllers\Site;

use App\Enums\CustomerType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Site\StoreEnquiryRequest;
use App\Services\Site\CatalogueService;
use App\Services\Site\EnquirySubmissionService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class EnquiryController extends Controller
{
    public function show(): View
    {
        return view('site.enquiry', ['types' => CustomerType::cases()]);
    }

    /**
     * Names and minimum orders for the ids kept in the visitor's browser.
     * Hidden or deleted products are simply left out.
     */
    public function products(Request $request, CatalogueService $catalogue): JsonResponse
    {
        $ids = collect(explode(',', (string) $request->query('ids', '')))
            ->filter(fn (string $id): bool => ctype_digit($id) && strlen($id) <= 9)
            ->map(fn (string $id): int => (int) $id)
            ->unique()
            ->take(50)
            ->values()
            ->all();

        $data = $catalogue->findVisible($ids)->map(fn ($p): array => [
            'id' => $p->id,
            'name' => $p->name,
            'url' => route('site.product', $p->slug),
            'moq' => $p->moq,
        ])->values();

        return response()->json($data);
    }

    public function store(StoreEnquiryRequest $request, EnquirySubmissionService $service): RedirectResponse
    {
        $data = $request->validated();

        $enquiry = $service->submit(
            collect($data)->only(['business_name', 'contact_name', 'email', 'phone', 'whatsapp', 'city', 'country', 'type'])->all(),
            array_values($data['items']),
            $data['message'] ?? null,
        );

        return redirect()->route('site.enquiry.thanks')->with('enquiry_reference', $enquiry->reference);
    }

    public function thanks(): View|RedirectResponse
    {
        $reference = session('enquiry_reference');

        return $reference === null
            ? redirect()->route('site.shop')
            : view('site.enquiry-thanks', ['reference' => $reference]);
    }
}
