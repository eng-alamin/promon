<?php

declare(strict_types=1);

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use App\Services\Site\CatalogueService;
use Illuminate\Contracts\View\View;

class PageController extends Controller
{
    public function about(CatalogueService $catalogue): View
    {
        return view('site.about', ['categories' => $catalogue->categories()]);
    }

    public function faq(): View
    {
        return view('site.faq', [
            'faqs' => Faq::active()->orderBy('sort_order')->orderBy('id')->get(),
        ]);
    }

    public function contact(): View
    {
        return view('site.contact');
    }
}
