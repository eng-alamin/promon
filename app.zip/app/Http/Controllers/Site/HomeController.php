<?php

declare(strict_types=1);

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Services\Site\CatalogueService;
use Illuminate\Contracts\View\View;

class HomeController extends Controller
{
    public function __invoke(CatalogueService $catalogue): View
    {
        return view('site.home', [
            'categories' => $catalogue->categories(),
            'popular' => $catalogue->popular(),
            'newArrivals' => $catalogue->newArrivals(),
        ]);
    }
}
