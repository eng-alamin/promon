<?php

declare(strict_types=1);

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Services\Site\CatalogueService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function __construct(private readonly CatalogueService $catalogue)
    {
    }

    public function index(Request $request): View
    {
        $categories = $this->catalogue->categories();

        // Unknown category or sort values fall back to "all" / default instead of erroring.
        $slug = (string) $request->query('category', '');
        $slug = $categories->contains('slug', $slug) ? $slug : '';

        $sort = (string) $request->query('sort', 'default');
        $sort = in_array($sort, CatalogueService::SORTS, true) ? $sort : 'default';

        $term = mb_substr(trim((string) $request->query('q', '')), 0, 100);

        return view('site.shop', [
            'categories' => $categories,
            'products' => $this->catalogue->search($slug, $term, $sort),
            'activeSlug' => $slug,
            'term' => $term,
            'sort' => $sort,
        ]);
    }

    public function show(string $slug): View
    {
        return view('site.product', ['product' => $this->catalogue->findBySlug($slug)]);
    }
}
