<?php

declare(strict_types=1);

namespace App\Http\Requests\Site;

use App\Enums\CustomerType;
use App\Services\Site\CatalogueService;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreEnquiryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /** @return array<string, mixed> */
    public function rules(): array
    {
        $phone = ['nullable', 'string', 'max:30', 'regex:/^[0-9+()\-\s.]{6,30}$/'];

        return [
            'business_name' => ['required', 'string', 'max:150'],
            'contact_name' => ['required', 'string', 'max:100'],
            'email' => ['nullable', 'email', 'max:150'],
            'phone' => $phone,
            'whatsapp' => $phone,
            'city' => ['nullable', 'string', 'max:100'],
            'country' => ['nullable', 'string', 'max:100'],
            'type' => ['required', Rule::enum(CustomerType::class)],
            'message' => ['nullable', 'string', 'max:2000'],
            // Honeypot: a real visitor never sees this field, so it must stay empty.
            'website' => ['nullable', 'max:0'],
            'items' => ['required', 'array', 'min:1', 'max:50'],
            'items.*.product_id' => ['required', 'integer', 'distinct'],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:99999'],
        ];
    }

    /** @return array<string, string> */
    public function messages(): array
    {
        return [
            'items.required' => 'Your enquiry list is empty. Add at least one product.',
            'items.min' => 'Your enquiry list is empty. Add at least one product.',
            'items.*.quantity.min' => 'Each quantity must be at least 1.',
            'items.*.quantity.integer' => 'Each quantity must be a whole number.',
            'website.max' => 'Could not send the enquiry.',
        ];
    }

    /** @return array<int, \Closure(Validator): void> */
    public function after(): array
    {
        return [
            function (Validator $validator): void {
                if ($validator->errors()->isNotEmpty()) {
                    return;
                }

                if (! $this->filled('email') && ! $this->filled('phone') && ! $this->filled('whatsapp')) {
                    $validator->errors()->add('email', 'Please give an email, phone or WhatsApp number so we can reply.');
                }

                $items = $this->input('items', []);
                $products = app(CatalogueService::class)
                    ->findVisible(array_map(fn ($i): int => (int) $i['product_id'], $items))
                    ->keyBy('id');

                foreach ($items as $index => $item) {
                    $product = $products->get((int) $item['product_id']);

                    if ($product === null) {
                        $validator->errors()->add("items.{$index}.product_id", 'A product in your list is no longer available. Please refresh the page.');
                    } elseif ($product->moq && (int) $item['quantity'] < $product->moq) {
                        $validator->errors()->add("items.{$index}.quantity", "{$product->name}: the minimum order is {$product->moq}.");
                    }
                }
            },
        ];
    }
}
