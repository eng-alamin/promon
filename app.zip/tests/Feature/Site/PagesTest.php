<?php

declare(strict_types=1);

namespace Tests\Feature\Site;

use App\Models\Category;
use App\Models\Faq;
use App\Models\Product;
use App\Models\Setting;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PagesTest extends TestCase
{
    use RefreshDatabase;

    public function test_faq_page_shows_only_active_questions_in_order(): void
    {
        Faq::create(['question' => 'Second one?', 'answer' => 'B', 'sort_order' => 2, 'is_active' => true]);
        Faq::create(['question' => 'First one?', 'answer' => 'A', 'sort_order' => 1, 'is_active' => true]);
        Faq::create(['question' => 'Hidden one?', 'answer' => 'C', 'sort_order' => 3, 'is_active' => false]);

        $this->get(route('site.faq'))
            ->assertOk()
            ->assertSeeInOrder(['First one?', 'Second one?'])
            ->assertDontSee('Hidden one?');
    }

    public function test_faq_page_escapes_html_in_answers(): void
    {
        Faq::create(['question' => 'Q?', 'answer' => '<script>alert(1)</script>', 'sort_order' => 1, 'is_active' => true]);

        $this->get(route('site.faq'))->assertOk()->assertDontSee('<script>alert(1)</script>', false);
    }

    public function test_contact_page_shows_only_filled_settings(): void
    {
        Setting::create(['key' => 'email', 'value' => 'hello@example.co.uk']);
        Setting::create(['key' => 'phone', 'value' => null]);

        $this->get(route('site.contact'))
            ->assertOk()
            ->assertSee('hello@example.co.uk')
            ->assertDontSee('Phone');
    }

    public function test_about_page_lists_active_categories(): void
    {
        Category::create(['name' => 'Grocery', 'slug' => 'grocery', 'sort_order' => 1, 'is_active' => true]);
        Category::create(['name' => 'Closed Group', 'slug' => 'closed', 'sort_order' => 2, 'is_active' => false]);

        $this->get(route('site.about'))->assertOk()->assertSee('Grocery')->assertDontSee('Closed Group');
    }

    public function test_unknown_page_shows_the_site_404(): void
    {
        $this->get('/no-such-page')->assertNotFound()->assertSee('Page not found');
    }

    public function test_sitemap_lists_visible_products_only(): void
    {
        $category = Category::create(['name' => 'Grocery', 'slug' => 'grocery', 'sort_order' => 1, 'is_active' => true]);
        foreach ([['tea-bags', true], ['secret-item', false]] as [$slug, $active]) {
            Product::create(['category_id' => $category->id, 'name' => $slug, 'slug' => $slug, 'price' => '1.00', 'status' => 'in_stock', 'is_active' => $active, 'sort_order' => 1]);
        }

        $this->get(route('site.sitemap'))
            ->assertOk()
            ->assertHeader('Content-Type', 'application/xml')
            ->assertSee('/products/tea-bags')
            ->assertDontSee('secret-item');
    }

    public function test_pages_are_noindex_outside_production(): void
    {
        $this->get(route('site.about'))->assertSee('noindex', false);
    }
}
