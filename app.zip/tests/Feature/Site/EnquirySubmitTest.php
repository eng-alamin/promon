<?php

declare(strict_types=1);

namespace Tests\Feature\Site;

use App\Models\Category;
use App\Models\Customer;
use App\Models\Enquiry;
use App\Models\EnquiryItem;
use App\Models\Product;
use App\Models\ProductPriceTier;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class EnquirySubmitTest extends TestCase
{
    use RefreshDatabase;

    private function makeProduct(string $name = 'Tea Bags', bool $active = true, ?int $moq = null): Product
    {
        $category = Category::firstOrCreate(['slug' => 'grocery'], ['name' => 'Grocery', 'sort_order' => 1, 'is_active' => true]);

        return Product::create([
            'category_id' => $category->id, 'name' => $name, 'slug' => str($name)->slug()->toString(),
            'price' => '9.50', 'moq' => $moq, 'status' => 'in_stock', 'is_active' => $active, 'sort_order' => 1,
        ]);
    }

    /** @param array<string, mixed> $over */
    private function payload(Product $product, int $qty = 12, array $over = []): array
    {
        return array_merge([
            'business_name' => 'Dhaka Mart', 'contact_name' => 'Rahim', 'type' => 'retailer',
            'email' => 'rahim@example.com',
            'items' => [['product_id' => $product->id, 'quantity' => $qty]],
        ], $over);
    }

    public function test_valid_enquiry_is_saved_with_price_snapshot(): void
    {
        $product = $this->makeProduct();
        ProductPriceTier::create(['product_id' => $product->id, 'min_qty' => 12, 'price' => '8.75']);

        $this->post(route('site.enquiry.submit'), $this->payload($product, 12))
            ->assertRedirect(route('site.enquiry.thanks'));

        $enquiry = Enquiry::with('items')->firstOrFail()->fresh();
        $this->assertSame('form', $enquiry->channel->value);
        $this->assertSame('new', $enquiry->status->value);
        $this->assertNull($enquiry->handled_by);
        $this->assertSame('8.75', EnquiryItem::firstOrFail()->unit_price);
        $this->assertSame(1, Customer::count());
    }

    public function test_same_email_reuses_customer_without_changing_it(): void
    {
        $product = $this->makeProduct();
        $this->post(route('site.enquiry.submit'), $this->payload($product));
        $this->post(route('site.enquiry.submit'), $this->payload($product, 5, ['business_name' => 'Changed Name']));

        $this->assertSame(1, Customer::count());
        $this->assertSame('Dhaka Mart', Customer::first()->business_name);
        $this->assertSame(2, Enquiry::count());
    }

    public function test_contact_method_is_required(): void
    {
        $product = $this->makeProduct();

        $this->post(route('site.enquiry.submit'), $this->payload($product, 12, ['email' => null]))->assertSessionHasErrors('email');
        $this->assertSame(0, Enquiry::count());
    }

    public function test_hidden_product_and_below_moq_are_rejected(): void
    {
        $hidden = $this->makeProduct('Hidden', false);
        $moq = $this->makeProduct('Bulk Item', true, 10);

        $this->post(route('site.enquiry.submit'), $this->payload($hidden))->assertSessionHasErrors('items.0.product_id');
        $this->post(route('site.enquiry.submit'), $this->payload($moq, 3))->assertSessionHasErrors('items.0.quantity');
        $this->assertSame(0, Enquiry::count());
    }

    public function test_empty_list_duplicate_products_and_honeypot_are_rejected(): void
    {
        $product = $this->makeProduct();

        $this->post(route('site.enquiry.submit'), $this->payload($product, 1, ['items' => []]))->assertSessionHasErrors('items');
        $this->post(route('site.enquiry.submit'), $this->payload($product, 1, ['items' => [
            ['product_id' => $product->id, 'quantity' => 1], ['product_id' => $product->id, 'quantity' => 2],
        ]]))->assertSessionHasErrors('items.0.product_id');
        $this->post(route('site.enquiry.submit'), $this->payload($product, 1, ['website' => 'spam']))->assertSessionHasErrors('website');
        $this->assertSame(0, Enquiry::count());
    }

    public function test_products_endpoint_returns_only_visible_products_and_ignores_junk(): void
    {
        $shown = $this->makeProduct();
        $hidden = $this->makeProduct('Hidden', false);

        $this->getJson(route('site.enquiry.products', ['ids' => "{$shown->id},{$hidden->id},abc,-1,1;DROP"]))
            ->assertOk()
            ->assertJsonCount(1)
            ->assertJsonPath('0.name', 'Tea Bags');
    }

    public function test_thanks_page_needs_a_fresh_submission(): void
    {
        $this->get(route('site.enquiry.thanks'))->assertRedirect(route('site.shop'));
        $this->withSession(['enquiry_reference' => 'ENQ-TEST'])->get(route('site.enquiry.thanks'))->assertOk()->assertSee('ENQ-TEST');
    }

    public function test_enquiry_page_loads(): void
    {
        $this->get(route('site.enquiry'))->assertOk()->assertSee('Enquiry list');
    }
}
