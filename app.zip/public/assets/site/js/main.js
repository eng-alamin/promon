(() => {
  'use strict';

  // Shared helpers. products.js merges into this object, so it must not replace it.
  const cfg = window.SITE_CONFIG || {};
  const waDigits = String(cfg.whatsapp || '').replace(/\D/g, '');
  const hasWhatsApp = /^\d{8,15}$/.test(waDigits);

  // Returns a wa.me link (with an optional ready-typed message), or null when no valid number is configured.
  function whatsappUrl(text) {
    if (!hasWhatsApp) return null;
    return 'https://wa.me/' + waDigits + (text ? '?text=' + encodeURIComponent(text) : '');
  }
  window.PROMON = Object.assign(window.PROMON || {}, { whatsappUrl });

  // Links marked data-whatsapp stay hidden unless a valid number is set in site-config.js.
  document.querySelectorAll('[data-whatsapp]').forEach((a) => {
    const url = whatsappUrl(a.dataset.waText);
    if (!url) return;
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener';
    a.hidden = false;
  });

  const toggle = document.querySelector('[data-menu-toggle]');
  const menu = document.querySelector('[data-menu]');
  if (toggle && menu) {
    const setOpen = (open) => {
      toggle.setAttribute('aria-expanded', String(open));
      menu.classList.toggle('hidden', !open);
    };
    toggle.addEventListener('click', () => setOpen(toggle.getAttribute('aria-expanded') !== 'true'));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') { setOpen(false); toggle.focus(); }
    });
    menu.addEventListener('click', (e) => { if (e.target.closest('a')) setOpen(false); });
    window.matchMedia('(min-width: 1024px)').addEventListener('change', (m) => { if (m.matches) setOpen(false); });
  }
  const year = document.querySelector('[data-year]');
  if (year) year.textContent = String(new Date().getFullYear());
})();
