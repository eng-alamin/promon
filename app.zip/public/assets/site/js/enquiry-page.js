(() => {
  'use strict';
  const { enquiry, whatsappUrl } = window.PROMON;
  const box = document.querySelector('[data-enquiry]');
  if (!box) return;

  const form = box.querySelector('[data-enquiry-form]');
  const listEl = box.querySelector('[data-enquiry-list]');
  const empty = box.querySelector('[data-enquiry-empty]');
  const waLink = box.querySelector('[data-enquiry-wa]');
  const clearBtn = box.querySelector('[data-enquiry-clear]');
  const heading = document.querySelector('[data-enquiry-heading]');
  const MAX_QTY = enquiry.MAX_QTY;

  let products = []; // [{ id, name, url, moq }] from the server

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  };

  function rows() {
    return enquiry.list()
      .map((item) => ({ item, p: products.find((x) => x.id === item.id) }))
      .filter((x) => x.p);
  }

  function updateWhatsApp() {
    const lines = rows().map((x, n) => `${n + 1}. ${x.p.name} (quantity: ${x.item.qty})`);
    const text = lines.length ? ['Hello, I would like to enquire about these products:', ...lines].join('\n') : '';
    const url = whatsappUrl(text);
    waLink.hidden = !url;
    if (url) { waLink.href = url; waLink.target = '_blank'; waLink.rel = 'noopener'; }
  }

  function row(item, p, index) {
    const li = el('li', 'card p-4 sm:flex sm:items-center sm:justify-between sm:gap-4');
    const left = el('div', 'min-w-0');
    const name = el('a', 'font-semibold text-ink hover:underline', p.name);
    name.href = p.url;
    left.append(name);
    if (p.moq) left.append(el('p', 'mt-1 text-sm text-muted', `Min. order: ${p.moq}`));

    const hidden = el('input');
    hidden.type = 'hidden';
    hidden.name = `items[${index}][product_id]`;
    hidden.value = String(p.id);

    const field = el('div');
    const label = el('label', 'block text-sm text-muted', 'Quantity');
    label.htmlFor = `qty-${p.id}`;
    label.append(el('span', 'sr-only', ` for ${p.name}`));
    const input = el('input', 'field mt-1 w-28');
    input.id = `qty-${p.id}`;
    input.name = `items[${index}][quantity]`;
    input.type = 'number';
    input.min = '1';
    input.max = String(MAX_QTY);
    input.step = '1';
    input.inputMode = 'numeric';
    input.value = String(item.qty);
    const note = el('p', 'mt-1 text-sm text-amber-200');
    note.setAttribute('role', 'status');
    const checkMoq = (q) => { note.textContent = p.moq && q < p.moq ? `Below the minimum order of ${p.moq}.` : ''; };
    checkMoq(item.qty);
    input.addEventListener('change', () => {
      const n = Number(input.value);
      if (enquiry.setQty(p.id, n)) {
        checkMoq(n);
        updateWhatsApp();
      } else {
        const current = enquiry.list().find((i) => i.id === p.id);
        input.value = String(current ? current.qty : 1);
        note.textContent = `Enter a whole number from 1 to ${MAX_QTY}.`;
      }
    });
    field.append(label, input, note);

    const rm = el('button', 'btn-ghost min-h-11', 'Remove');
    rm.type = 'button';
    rm.setAttribute('aria-label', `Remove ${p.name} from the enquiry list`);
    rm.addEventListener('click', () => {
      enquiry.remove(p.id);
      enquiry.announce(`${p.name} removed from the enquiry list.`);
      render();
      if (heading) heading.focus();
    });

    const right = el('div', 'mt-3 flex flex-wrap items-end gap-3 sm:mt-0');
    right.append(field, rm);
    li.append(left, hidden, right);
    return li;
  }

  function render() {
    const list = rows();
    listEl.replaceChildren(...list.map((x, i) => row(x.item, x.p, i)));
    form.hidden = list.length === 0;
    empty.hidden = list.length > 0;
    updateWhatsApp();
  }

  clearBtn.addEventListener('click', () => {
    if (!window.confirm('Remove all products from your enquiry list?')) return;
    enquiry.clear();
    enquiry.announce('The enquiry list is now empty.');
    render();
    if (heading) heading.focus();
  });

  window.addEventListener('storage', render);

  // Ask the server which of the saved products still exist, then draw the list.
  async function load() {
    const ids = enquiry.list().map((i) => i.id);
    if (ids.length === 0) { render(); return; }
    try {
      const res = await fetch(`${window.ENQUIRY_PRODUCTS_URL}?ids=${ids.join(',')}`, { headers: { Accept: 'application/json' } });
      if (!res.ok) throw new Error(String(res.status));
      products = await res.json();
      enquiry.prune(new Set(products.map((p) => p.id)));
    } catch {
      empty.textContent = 'The enquiry list could not be loaded. Please refresh the page.';
      return;
    }
    render();
  }
  load();
})();
