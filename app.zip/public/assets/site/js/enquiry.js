(() => {
  'use strict';

  // Enquiry list: a simple "shopping list" without prices or payment.
  // It is kept in this browser (localStorage). If storage is blocked it still works until the page is closed.
  const KEY = 'promon-enquiry-list';
  const MAX_ITEMS = 50;
  const MAX_QTY = 99999;

  function sanitize(raw) {
    if (!Array.isArray(raw)) return [];
    const seen = new Set();
    const out = [];
    for (const item of raw) {
      const id = Number(item && item.id);
      const qty = Number(item && item.qty);
      if (!Number.isInteger(id) || id < 1 || seen.has(id)) continue;
      if (!Number.isInteger(qty) || qty < 1 || qty > MAX_QTY) continue;
      seen.add(id);
      out.push({ id, qty });
      if (out.length === MAX_ITEMS) break;
    }
    return out;
  }

  function load() {
    try {
      const raw = window.localStorage.getItem(KEY);
      return sanitize(raw ? JSON.parse(raw) : []);
    } catch {
      return [];
    }
  }

  let items = load();

  function save() {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(items));
    } catch {
      // Storage is blocked (private mode, full). The list stays in memory for this page view.
    }
    changed();
  }

  let live = null;
  function announce(message) {
    if (!live) {
      live = document.createElement('div');
      live.className = 'sr-only';
      live.setAttribute('role', 'status');
      live.setAttribute('aria-live', 'polite');
      document.body.append(live);
    }
    live.textContent = '';
    window.setTimeout(() => { live.textContent = message; }, 50);
  }

  const has = (id) => items.some((i) => i.id === id);
  const count = () => items.length;
  const list = () => items.map((i) => ({ ...i }));

  function add(id, qty = 1) {
    if (has(id)) return { ok: true };
    if (items.length >= MAX_ITEMS) return { ok: false, reason: 'full' };
    items.push({ id, qty });
    save();
    return { ok: true };
  }
  function remove(id) {
    items = items.filter((i) => i.id !== id);
    save();
  }
  function setQty(id, qty) {
    const n = Number(qty);
    if (!Number.isInteger(n) || n < 1 || n > MAX_QTY) return false;
    const item = items.find((i) => i.id === id);
    if (!item) return false;
    item.qty = n;
    save();
    return true;
  }
  function clear() {
    items = [];
    save();
  }
  // Drop ids that are no longer in the catalogue.
  function prune(validIds) {
    const next = items.filter((i) => validIds.has(i.id));
    if (next.length !== items.length) {
      items = next;
      save();
    }
  }

  // Text for WhatsApp / the contact form. Needs products.js on the page, otherwise returns ''.
  function messageText() {
    const products = (window.PROMON && window.PROMON.PRODUCTS) || [];
    const lines = items
      .map((i) => ({ p: products.find((p) => p.id === i.id), qty: i.qty }))
      .filter((x) => x.p)
      .map((x, n) => `${n + 1}. ${x.p.name} (quantity: ${x.qty})`);
    if (lines.length === 0) return '';
    return ['Hello Promon, I would like to enquire about these products:', ...lines].join('\n');
  }

  // ---- page wiring: header count and every add/remove button ----
  function changed() {
    document.querySelectorAll('[data-enquiry-count]').forEach((n) => {
      n.textContent = items.length > 0 ? ` (${items.length})` : '';
    });
    document.querySelectorAll('[data-enquiry-id]').forEach(paintButton);
    document.dispatchEvent(new CustomEvent('promon:enquiry'));
  }

  function paintButton(btn) {
    const id = Number(btn.dataset.enquiryId);
    const name = btn.dataset.enquiryName || 'this product';
    const inList = has(id);
    btn.textContent = inList ? 'Remove from enquiry list' : 'Add to enquiry list';
    btn.setAttribute('aria-label', `${inList ? 'Remove from' : 'Add to'} enquiry list: ${name}`);
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-enquiry-id]');
    if (!btn) return;
    const id = Number(btn.dataset.enquiryId);
    const name = btn.dataset.enquiryName || 'Product';
    if (has(id)) {
      remove(id);
      announce(`${name} removed from the enquiry list.`);
    } else if (add(id).ok) {
      announce(`${name} added to the enquiry list.`);
    } else {
      announce(`The enquiry list is full (${MAX_ITEMS} products). Remove one first.`);
    }
  });

  // Another tab changed the list.
  window.addEventListener('storage', (e) => {
    if (e.key === KEY) { items = load(); changed(); }
  });

  document.addEventListener('DOMContentLoaded', changed);

  window.PROMON = Object.assign(window.PROMON || {}, {
    enquiry: { has, add, remove, setQty, clear, prune, list, count, messageText, announce, paintButton, MAX_ITEMS, MAX_QTY }
  });
})();
