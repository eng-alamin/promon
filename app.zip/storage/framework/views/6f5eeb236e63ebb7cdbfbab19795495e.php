<?php
    use Illuminate\Support\Str;

    // route = null means the module is not built yet (shown dimmed, not clickable).
    $items = [
        ['label' => 'Home', 'icon' => 'bi-grid', 'route' => 'admin.dashboard', 'active' => ['admin.dashboard']],
        ['label' => 'Enquiries', 'icon' => 'bi-chat-left-text', 'route' => 'admin.enquiries.index', 'active' => ['admin.enquiries.*']],
        ['label' => 'Categories', 'icon' => 'bi-tags', 'route' => 'admin.categories.index', 'active' => ['admin.categories.*']],
        ['label' => 'Customers', 'icon' => 'bi-people', 'route' => 'admin.customers.index', 'active' => ['admin.customers.*']],
        ['label' => 'FAQs', 'icon' => 'bi-question-circle', 'route' => 'admin.faqs.index', 'active' => ['admin.faqs.*']],
        ['label' => 'Users', 'icon' => 'bi-person-gear', 'route' => 'admin.users.index', 'active' => ['admin.users.*'], 'superAdminOnly' => true],
        ['label' => 'Settings', 'icon' => 'bi-gear', 'route' => 'admin.settings.edit', 'active' => ['admin.settings.*'], 'superAdminOnly' => true],
    ];
?>

<nav class="rail" aria-label="Main">
    <a class="logo" href="<?php echo e(route('admin.dashboard')); ?>" aria-label="<?php echo e(config('app.name')); ?> home"><?php echo e(Str::upper(Str::substr(config('app.name'), 0, 1))); ?></a>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <?php if(($item['superAdminOnly'] ?? false) && ! auth()->user()->isSuperAdmin()): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php continue; ?><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['route']): ?>
            <?php ($isActive = request()->routeIs(...$item['active'])); ?>
            <a href="<?php echo e(route($item['route'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-i', 'on' => $isActive]); ?>" <?php if($isActive): ?> aria-current="page" <?php endif; ?>>
                <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i><span><?php echo e($item['label']); ?></span>
            </a>
        <?php else: ?>
            <span class="nav-i soon" role="link" aria-disabled="true" title="Coming in a later step">
                <i class="bi <?php echo e($item['icon']); ?>" aria-hidden="true"></i><span><?php echo e($item['label']); ?> (soon)</span>
            </span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    <span class="sp"></span>

    <form method="POST" action="<?php echo e(route('admin.logout')); ?>" style="display:contents">
        <?php echo csrf_field(); ?>
        <button type="submit" class="nav-i" aria-label="Log out">
            <i class="bi bi-box-arrow-right" aria-hidden="true"></i><span>Log out</span>
        </button>
    </form>
</nav>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/admin/partials/rail.blade.php ENDPATH**/ ?>