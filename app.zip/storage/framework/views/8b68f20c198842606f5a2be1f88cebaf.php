<?php $__env->startSection('title', 'New enquiry'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <p><a class="btn" href="<?php echo e(route('admin.enquiries.index')); ?>"><i class="bi bi-arrow-left" aria-hidden="true"></i> Back to enquiries</a></p>

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.enquiries.enquiry-form', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1254710274-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\promon\resources\views/admin/enquiries/create.blade.php ENDPATH**/ ?>