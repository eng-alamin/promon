<?php if (isset($component)) { $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $attributes; } ?>
<?php $component = App\View\Components\Site\Layout::resolve(['title' => 'FAQ','description' => 'Quick answers about prices, ordering, delivery and getting in touch.','nav' => 'faq'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Site\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 class="text-4xl font-bold">Frequently asked questions</h1>
      <p class="mt-2 max-w-2xl text-muted">Quick answers about prices, ordering, delivery and getting in touch. Open a question to read the answer.</p>
    </div>
  </section>
  <section class="container-page py-10">
    <div class="max-w-3xl space-y-3">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <details name="faq" class="group card">
          <summary class="flex cursor-pointer list-none items-center justify-between gap-4 p-5 font-semibold text-ink [&::-webkit-details-marker]:hidden"><span><?php echo e($faq->question); ?></span><svg class="size-5 shrink-0 text-brand-100 transition-transform duration-200 group-open:rotate-180" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></summary>
          <div class="px-5 pb-5 leading-relaxed text-muted whitespace-pre-line break-words"><?php echo e($faq->answer); ?></div>
        </details>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <p class="text-muted">No questions have been added yet. Please <a class="underline" href="<?php echo e(route('site.contact')); ?>">contact us</a>.</p>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
    <p class="mt-8 text-muted">Cannot find your answer? <a class="underline" href="<?php echo e(route('site.contact')); ?>">Contact us</a>.</p>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $attributes = $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $component = $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/site/faq.blade.php ENDPATH**/ ?>