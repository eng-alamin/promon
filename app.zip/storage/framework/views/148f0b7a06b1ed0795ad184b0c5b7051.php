<?php if (isset($component)) { $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $attributes; } ?>
<?php $component = App\View\Components\Site\Layout::resolve(['title' => 'FAQ','description' => 'Quick answers about ordering, payment, delivery and getting in touch.','nav' => 'faq'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Site\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

  <section class="page-head">
    <div class="wrap">
      <p class="eyebrow">FAQ</p>
      <h1>Frequently asked questions.</h1>
      <p class="lead">Quick answers about ordering, payment, delivery and getting in touch.</p>
    </div>
  </section>
  <section class="page-body">
    <div class="wrap faq" style="max-width: 820px">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <details name="faq">
          <summary><?php echo e($faq->question); ?></summary>
          <div class="ans"><?php echo e($faq->answer); ?></div>
        </details>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <p class="lead" style="margin-top:0">No questions have been added yet. Please <a class="link-gold" href="<?php echo e(route('site.home')); ?>#contact">contact us</a>.</p>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      <p class="lead">Cannot find your answer? <a class="link-gold" href="<?php echo e(route('site.home')); ?>#contact">Contact us</a>.</p>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $attributes = $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $component = $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/site/faq.blade.php ENDPATH**/ ?>