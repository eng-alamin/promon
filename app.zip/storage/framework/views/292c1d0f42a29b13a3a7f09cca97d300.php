<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $image = $product->primaryImage?->url;
    $letter = mb_substr($product->category?->name ?? $product->name, 0, 1);
    $href = route('site.product', $product->slug);
?>
<li>
  <article class="card card-hover flex h-full flex-col overflow-hidden">
    <a href="<?php echo e($href); ?>" class="block" tabindex="-1" aria-hidden="true">
      <div class="relative aspect-4/3 overflow-hidden bg-brand-50" aria-hidden="true">
        <span class="grid size-full place-items-center font-display text-4xl text-brand-100"><?php echo e($letter); ?></span>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($image): ?>
          <img src="<?php echo e($image); ?>" alt="" loading="lazy" decoding="async" class="absolute inset-0 size-full object-cover" onerror="this.remove()">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </div>
    </a>
    <div class="flex flex-1 flex-col p-4">
      <p class="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted">
        <span><?php echo e($product->category?->name); ?></span>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->is_new): ?><span class="rounded-full bg-accent-500 px-2 py-0.5 text-canvas">New</span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </p>
      <h3 class="mt-1 flex-1 text-base leading-snug"><a class="hover:underline" href="<?php echo e($href); ?>"><?php echo e($product->name); ?></a></h3>
      <p class="mt-3"><span class="sr-only">Price: </span><span class="text-lg font-bold text-ink">£<?php echo e(number_format((float) $product->price, 2)); ?></span></p>
      <p class="mt-1 text-sm text-muted">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->moq): ?> Min. order: <?php echo e($product->moq); ?> · <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php echo e($product->status->label()); ?>

      </p>
      <button type="button" class="btn-ghost mt-4 min-h-11 text-center" data-enquiry-id="<?php echo e($product->id); ?>" data-enquiry-name="<?php echo e($product->name); ?>">Add to enquiry list</button>
    </div>
  </article>
</li>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/components/site/product-card.blade.php ENDPATH**/ ?>