<nav class="subtabs" aria-label="Catalogue">
    <a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('admin.products.*')]); ?>" <?php if(request()->routeIs('admin.products.*')): ?> aria-current="page" <?php endif; ?>>Products</a>
    <a href="<?php echo e(route('admin.categories.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('admin.categories.*')]); ?>" <?php if(request()->routeIs('admin.categories.*')): ?> aria-current="page" <?php endif; ?>>Categories</a>
    <a href="<?php echo e(route('admin.brands.index')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('admin.brands.*')]); ?>" <?php if(request()->routeIs('admin.brands.*')): ?> aria-current="page" <?php endif; ?>>Brands</a>
</nav>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/admin/partials/catalogue-tabs.blade.php ENDPATH**/ ?>