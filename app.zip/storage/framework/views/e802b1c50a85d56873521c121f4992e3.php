<div class="card">
    <h2 class="sec">Images</h2>
    <p class="hint">JPG, PNG or WebP, up to 2 MB each, at most <?php echo e($maxImages); ?> images. The primary image is shown first on the website.</p>

    <label for="product-uploads">Add images</label>
    <input class="f" id="product-uploads" type="file" accept="image/jpeg,image/png,image/webp" multiple wire:model="uploads" <?php $__errorArgs = ['uploads'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" aria-describedby="product-uploads-error" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
    <p class="hint" wire:loading wire:target="uploads">Uploading...</p>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['uploads'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="err-msg" id="product-uploads-error"><i class="bi bi-exclamation-circle" aria-hidden="true"></i><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($images->isEmpty()): ?>
        <div class="empty">
            <div class="empty-ic" aria-hidden="true"><i class="bi bi-image"></i></div>
            <h3>No images yet</h3>
            <p>Choose one or more files above. The first image becomes the primary image.</p>
        </div>
    <?php else: ?>
        <ul class="imgs">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <li <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'image-'.e($image->id).''; ?>wire:key="image-<?php echo e($image->id); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['img', 'is-primary' => $image->is_primary]); ?>">
                    <img src="<?php echo e($image->url); ?>" alt="<?php echo e($image->alt_text); ?>" loading="lazy">
                    <div class="img-bar">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($image->is_primary): ?>
                            <span class="pill ok">Primary</span>
                        <?php else: ?>
                            <button class="btn" type="button" wire:click="setPrimary(<?php echo e($image->id); ?>)">Make primary</button>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <span class="img-acts">
                            <button class="ib" type="button" wire:click="moveUp(<?php echo e($image->id); ?>)" <?php if($loop->first): echo 'disabled'; endif; ?> aria-label="Move image <?php echo e($loop->iteration); ?> earlier"><i class="bi bi-arrow-left" aria-hidden="true"></i></button>
                            <button class="ib" type="button" wire:click="moveDown(<?php echo e($image->id); ?>)" <?php if($loop->last): echo 'disabled'; endif; ?> aria-label="Move image <?php echo e($loop->iteration); ?> later"><i class="bi bi-arrow-right" aria-hidden="true"></i></button>
                            <button class="ib bad" type="button" wire:click="delete(<?php echo e($image->id); ?>)" wire:confirm="Delete this image? This cannot be undone." aria-label="Delete image <?php echo e($loop->iteration); ?>"><i class="bi bi-trash" aria-hidden="true"></i></button>
                        </span>
                    </div>
                </li>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </ul>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/livewire/admin/products/product-images.blade.php ENDPATH**/ ?>