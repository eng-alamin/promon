<?php if (isset($component)) { $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $attributes; } ?>
<?php $component = App\View\Components\Site\Layout::resolve(['title' => 'Page not found','description' => '','nav' => ''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Site\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

  <section class="page-head">
    <div class="wrap">
      <p class="eyebrow">Error 404</p>
      <h1>Page not found</h1>
      <p class="lead">The page you asked for does not exist or has moved. Check the address, or use one of the links below.</p>
    </div>
  </section>
  <section class="page-body">
    <div class="wrap">
      <a class="btn btn--gold" href="<?php echo e(route('site.home')); ?>">Go to the home page</a>
      <a class="btn btn--line" href="<?php echo e(route('site.enquiry')); ?>">Send an enquiry</a>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $attributes = $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $component = $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/errors/404.blade.php ENDPATH**/ ?>