<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->hasPages()): ?>
  <nav aria-label="Pagination" class="flex flex-wrap items-center justify-between gap-3">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->onFirstPage()): ?>
      <span class="btn-ghost min-h-11 opacity-50" aria-disabled="true">Previous</span>
    <?php else: ?>
      <a class="btn-ghost min-h-11" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">Previous</a>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <p class="text-sm text-muted">Page <?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?></p>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->hasMorePages()): ?>
      <a class="btn-ghost min-h-11" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Next</a>
    <?php else: ?>
      <span class="btn-ghost min-h-11 opacity-50" aria-disabled="true">Next</span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </nav>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/site/pagination.blade.php ENDPATH**/ ?>