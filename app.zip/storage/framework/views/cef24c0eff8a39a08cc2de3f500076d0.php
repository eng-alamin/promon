<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['review', 'limit' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['review', 'limit' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<figure class="review">
  <div class="stars" role="img" aria-label="Rated <?php echo e($review->rating); ?> out of 5">
    <span aria-hidden="true"><?php echo e(str_repeat('★', $review->rating)); ?><span class="off"><?php echo e(str_repeat('★', 5 - $review->rating)); ?></span></span>
  </div>
  <blockquote>
    <p><?php echo e($limit ? \Illuminate\Support\Str::limit($review->body, $limit) : $review->body); ?></p>
  </blockquote>
  <figcaption>
    <b><?php echo e($review->reviewer_name); ?></b>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($review->reviewer_title): ?><span><?php echo e($review->reviewer_title); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  </figcaption>
</figure>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/components/site/review-card.blade.php ENDPATH**/ ?>