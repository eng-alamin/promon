<?php if (isset($component)) { $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $attributes; } ?>
<?php $component = App\View\Components\Site\Layout::resolve(['title' => 'Reviews','description' => 'Read what retailers, wholesalers and personal customers say about PROMON LTD and our UK to Bangladesh sourcing service.','nav' => 'reviews'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Site\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

  <section class="page-head">
    <div class="wrap">
      <p class="eyebrow">Reviews</p>
      <h1>What our customers say.</h1>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($average !== null): ?>
        <p class="lead"><?php echo e(number_format($average, 1)); ?> out of 5 &middot; <?php echo e($reviews->count()); ?> <?php echo e($reviews->count() === 1 ? 'review' : 'reviews'); ?></p>
      <?php else: ?>
        <p class="lead">Feedback from retailers, wholesalers and personal customers.</p>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
  </section>

  <section class="page-body">
    <div class="wrap">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loop->first): ?><div class="reviews"><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalad533f9c051dead466c979e382e27833 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad533f9c051dead466c979e382e27833 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.review-card','data' => ['review' => $review]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.review-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['review' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($review)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad533f9c051dead466c979e382e27833)): ?>
<?php $attributes = $__attributesOriginalad533f9c051dead466c979e382e27833; ?>
<?php unset($__attributesOriginalad533f9c051dead466c979e382e27833); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad533f9c051dead466c979e382e27833)): ?>
<?php $component = $__componentOriginalad533f9c051dead466c979e382e27833; ?>
<?php unset($__componentOriginalad533f9c051dead466c979e382e27833); ?>
<?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loop->last): ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <p class="lead" style="margin-top:0">No reviews have been added yet. Please <a class="link-gold" href="<?php echo e(route('site.contact')); ?>">contact us</a>.</p>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

      <div class="about-cta" style="margin-top:48px">
        <div>
          <h3>Ready to order from the UK?</h3>
          <p>Send us the product name, quantity and delivery destination and we will reply with the details.</p>
        </div>
        <div class="about-cta__btns">
          <a class="btn btn--gold" href="<?php echo e(route('site.enquiry')); ?>">Send an enquiry</a>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(strlen($waDigits) >= 8): ?><a class="btn btn--line" href="https://wa.me/<?php echo e($waDigits); ?>" target="_blank" rel="noopener">WhatsApp<span class="sr-only"> (opens in a new tab)</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
      </div>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $attributes = $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $component = $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/site/reviews.blade.php ENDPATH**/ ?>