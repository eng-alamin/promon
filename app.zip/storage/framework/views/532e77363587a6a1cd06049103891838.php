<?php
    use Illuminate\Support\Str;

    $user = auth()->user();
?>

<header class="top">
    <h1><?php echo $__env->yieldContent('title', 'Dashboard'); ?></h1>

    <button class="ib" id="themeBtn" type="button" aria-label="Toggle dark mode"><i class="bi bi-moon-stars" aria-hidden="true"></i></button>

    <div class="who">
        <span class="av" aria-hidden="true"><?php echo e(Str::upper(Str::substr($user->name, 0, 1))); ?></span>
        
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/admin/partials/topbar.blade.php ENDPATH**/ ?>