<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <p class="lead">Welcome back, <?php echo e(auth()->user()->name); ?>.</p>

        <h2 class="sec">Enquiries</h2>
        <div class="kpi">
            <div class="card"><small>New enquiries</small><b><?php echo e(number_format($summary['new_enquiries'])); ?></b></div>
            <div class="card"><small>Total enquiries</small><b><?php echo e(number_format($summary['total_enquiries'])); ?></b></div>
            <div class="card"><small>Customers</small><b><?php echo e(number_format($summary['customers'])); ?></b></div>
            <div class="card"><small>Active categories</small><b><?php echo e(number_format($summary['categories'])); ?></b></div>
        </div>

        <h2 class="sec">Recent enquiries</h2>
        <div class="card">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($summary['recent_enquiries']->isEmpty()): ?>
                <div class="empty">
                    <div class="empty-ic" aria-hidden="true"><i class="bi bi-chat-left-text"></i></div>
                    <h3>No enquiries yet</h3>
                    <p>New enquiries from the website and WhatsApp will appear here.</p>
                </div>
            <?php else: ?>
                <table>
                    <tr>
                        <th scope="col">Reference</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Channel</th>
                        <th scope="col">Status</th>
                        <th scope="col">Received</th>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $summary['recent_enquiries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr>
                            <td data-label="Reference"><a href="<?php echo e(route('admin.enquiries.show', $enquiry)); ?>"><code><?php echo e($enquiry->reference); ?></code></a></td>
                            <td data-label="Customer"><?php echo e($enquiry->customer->business_name ?: $enquiry->customer->contact_name); ?></td>
                            <td data-label="Channel"><?php echo e($enquiry->channel->label()); ?></td>
                            <td data-label="Status"><?php if (isset($component)) { $__componentOriginal6506b403466a5cd22db8b21c3bf79bc8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6506b403466a5cd22db8b21c3bf79bc8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.status-pill','data' => ['status' => $enquiry->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($enquiry->status)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6506b403466a5cd22db8b21c3bf79bc8)): ?>
<?php $attributes = $__attributesOriginal6506b403466a5cd22db8b21c3bf79bc8; ?>
<?php unset($__attributesOriginal6506b403466a5cd22db8b21c3bf79bc8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6506b403466a5cd22db8b21c3bf79bc8)): ?>
<?php $component = $__componentOriginal6506b403466a5cd22db8b21c3bf79bc8; ?>
<?php unset($__componentOriginal6506b403466a5cd22db8b21c3bf79bc8); ?>
<?php endif; ?></td>
                            <td data-label="Received" title="<?php echo e($enquiry->created_at->format('d M Y, H:i')); ?>"><?php echo e($enquiry->created_at->diffForHumans()); ?></td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </table>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\promon\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>