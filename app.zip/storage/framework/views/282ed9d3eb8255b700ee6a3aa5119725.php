<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['category', 'icons' => [], 'blurbs' => [], 'defaultIcon' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['category', 'icons' => [], 'blurbs' => [], 'defaultIcon' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<li style="display:contents">
  <a class="cat" href="<?php echo e(route('site.enquiry', ['category' => $category->slug])); ?>">
    <svg viewBox="0 0 24 24" aria-hidden="true"><?php echo $icons[$category->slug] ?? $defaultIcon; ?></svg>
    <span>
      <h3><?php echo e($category->name); ?></h3>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($blurbs[$category->slug])): ?><p><?php echo e($blurbs[$category->slug]); ?></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      <em>Enquire &rarr;</em>
    </span>
  </a>
</li>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/components/site/cat-tile.blade.php ENDPATH**/ ?>