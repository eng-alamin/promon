<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($paginator->hasPages()): ?>
    <nav class="pager" aria-label="Pagination">
        <span class="muted">Showing <?php echo e($paginator->firstItem()); ?>-<?php echo e($paginator->lastItem()); ?> of <?php echo e($paginator->total()); ?></span>
        <span class="btns">
            <button class="btn" type="button" wire:click="previousPage('<?php echo e($paginator->getPageName()); ?>')" <?php if($paginator->onFirstPage()): echo 'disabled'; endif; ?>>Previous</button>
            <button class="btn" type="button" wire:click="nextPage('<?php echo e($paginator->getPageName()); ?>')" <?php if(! $paginator->hasMorePages()): echo 'disabled'; endif; ?>>Next</button>
        </span>
    </nav>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/livewire/admin/pagination.blade.php ENDPATH**/ ?>