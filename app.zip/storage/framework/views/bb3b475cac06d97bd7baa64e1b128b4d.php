<?php
    $phoneBd = '+880 1676 213722';
    $mapQuery = urlencode('House 2/A, Road 13, Sector 4, Uttara, Dhaka 1230, Bangladesh');
?>
<?php if (isset($component)) { $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $attributes; } ?>
<?php $component = App\View\Components\Site\Layout::resolve(['title' => 'Contact','description' => 'Contact PROMON LTD in the UK or K Pharma in Uttara, Dhaka. Email, WhatsApp and phone details for UK product enquiries.','nav' => 'contact'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Site\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

  <section class="page-head">
    <div class="wrap">
      <p class="eyebrow">Contact</p>
      <h1>Let's work together.</h1>
      <p class="lead">Message us on WhatsApp or send an email. To enquire about products, choose your categories on the enquiry page.</p>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="contact">
        <div>
          <dl>
            <div class="row"><dt>United Kingdom</dt><dd>PROMON LTD<br>1A Wilmot Street, Bolton, Manchester, BL1 3LL<br>Company number 13358479</dd></div>
            <div class="row"><dt>Bangladesh</dt><dd>K Pharma (sister concern)<br>House 2/A, Road 13, Sector 4, Uttara, Dhaka 1230<br><a href="tel:+8801676213722"><?php echo e($phoneBd); ?></a></dd></div>
            <div class="row"><dt>Direct</dt><dd>
              <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(strlen($waDigits) >= 8): ?><br>WhatsApp: <a href="https://wa.me/<?php echo e($waDigits); ?>" target="_blank" rel="noopener"><?php echo e($whatsapp); ?><span class="sr-only"> (opens in a new tab)</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </dd></div>
          </dl>
        </div>
        <div class="cta-box">
          <h3>Which UK product do you need?</h3>
          <p>Choose your categories and send the enquiry on WhatsApp. Or message us with a photo and the details to get a price.</p>
          <a class="btn btn--gold" href="<?php echo e(route('site.enquiry')); ?>">Send an enquiry</a>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(strlen($waDigits) >= 8): ?><a class="btn btn--line" href="https://wa.me/<?php echo e($waDigits); ?>" target="_blank" rel="noopener">WhatsApp<span class="sr-only"> (opens in a new tab)</span></a><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <section class="section dhaka">
    <div class="wrap">
      <div class="box">
        <div>
          <p class="eyebrow">Visit us in Dhaka</p>
          <h2>K Pharma</h2>
          <p>Our sister concern medicine store in Uttara, stocking PROMON's UK products.</p>
          <address>House 2/A, Road 13, Sector 4, Uttara,<br>Dhaka 1230, Bangladesh<br><a href="tel:+8801676213722"><?php echo e($phoneBd); ?></a></address>
          <a class="btn btn--gold btn--sm" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&amp;query=<?php echo e($mapQuery); ?>">Open in Google Maps<span class="sr-only"> (opens in a new tab)</span></a>
        </div>
        <iframe class="map" title="Map of K Pharma, Uttara, Dhaka" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=<?php echo e($mapQuery); ?>&amp;output=embed"></iframe>
      </div>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $attributes = $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $component = $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/site/contact.blade.php ENDPATH**/ ?>