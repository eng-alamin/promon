<?php
    $details = array_filter([
        'Email' => $settings['email'] ?? null,
        'Phone' => $settings['phone'] ?? null,
        'Opening hours' => $settings['working_hours'] ?? null,
    ], fn ($v) => filled($v));
    $address = $settings['address'] ?? null;
?>
<?php if (isset($component)) { $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $attributes; } ?>
<?php $component = App\View\Components\Site\Layout::resolve(['title' => 'Contact','description' => 'Contact '.e($company).' on WhatsApp or by email to ask about products and prices.','nav' => 'contact'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Site\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 class="text-4xl font-bold">Contact us</h1>
      <p class="mt-2 max-w-2xl text-muted">Message us on WhatsApp, or send an enquiry with the products you need. There is no online checkout.</p>
    </div>
  </section>
  <section class="container-page grid gap-8 py-10 lg:grid-cols-2">
    <div class="card space-y-5 p-6">
      <h2 class="text-2xl font-bold">Get in touch</h2>
      <div class="flex flex-wrap gap-3">
        <a data-whatsapp href="<?php echo e(route('site.enquiry')); ?>" hidden class="btn-primary min-h-11">Chat on WhatsApp<span class="sr-only"> (opens in a new tab)</span></a>
        <a class="btn-ghost min-h-11" href="<?php echo e(route('site.enquiry')); ?>">Send an enquiry</a>
      </div>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($details !== [] || filled($address)): ?>
        <dl class="grid grid-cols-[max-content_1fr] gap-x-6 gap-y-2 text-sm">
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <dt class="text-muted"><?php echo e($label); ?></dt><dd class="font-medium text-ink break-words"><?php echo e($value); ?></dd>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($address)): ?>
            <dt class="text-muted">Address</dt><dd class="font-medium text-ink whitespace-pre-line break-words"><?php echo e($address); ?></dd>
          <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </dl>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
    <div class="card space-y-3 p-6">
      <h2 class="text-2xl font-bold">Before you write</h2>
      <p class="text-muted">Tell us the products, the quantities and where the goods should go. Our reply will include prices in pounds sterling (£) and delivery details.</p>
      <p><a class="underline" href="<?php echo e(route('site.faq')); ?>">Read the FAQ</a></p>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $attributes = $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $component = $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/site/contact.blade.php ENDPATH**/ ?>