<?php if (isset($component)) { $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b = $attributes; } ?>
<?php $component = App\View\Components\Site\Layout::resolve(['title' => 'About us','description' => 'Promon supplies UK products to wholesalers and retailers in Bangladesh and other countries.','nav' => 'about'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Site\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

  <section class="border-b border-line">
    <div class="container-page py-10">
      <h1 class="text-4xl font-bold">About us</h1>
      <p class="mt-2 max-w-2xl text-muted"><?php echo e($settings['tagline'] ?? 'We supply UK products to wholesalers and retailers in Bangladesh and other countries.'); ?></p>
    </div>
  </section>
  <section class="container-page grid gap-8 py-10 lg:grid-cols-2">
    <div class="card space-y-3 p-6">
      <h2 class="text-2xl font-bold">What we supply</h2>
      <p class="text-muted">We work in <?php echo e($categories->count()); ?> product categories. Pick a category to see its products.</p>
      <ul class="flex flex-wrap gap-2">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <li><a class="inline-block rounded-full border border-white/20 bg-white/6 px-4 py-2 text-sm font-medium text-ink hover:border-white/40" href="<?php echo e(route('site.shop', ['category' => $category->slug])); ?>"><?php echo e($category->name); ?></a></li>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      </ul>
    </div>
    <div class="space-y-4">
      <div class="card p-6"><h2 class="text-2xl font-bold">Prices in pounds</h2><p class="mt-2 text-muted">Every price on the site is in pounds sterling (£ GBP).</p></div>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($settings['delivery_time'] ?? null)): ?>
        <div class="card p-6"><h2 class="text-2xl font-bold">Delivery</h2><p class="mt-2 text-muted"><?php echo e($settings['delivery_time']); ?></p></div>
      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      <div class="card p-6"><h2 class="text-2xl font-bold">Have a question?</h2><p class="mt-2 text-muted">Check the FAQ first, or message us.</p>
        <div class="mt-4 flex flex-wrap gap-3"><a class="btn-ghost" href="<?php echo e(route('site.faq')); ?>">Read the FAQ</a><a class="btn-primary" href="<?php echo e(route('site.contact')); ?>">Contact us</a></div>
      </div>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $attributes = $__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__attributesOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b)): ?>
<?php $component = $__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b; ?>
<?php unset($__componentOriginal5dd318aa4aed784d83dcdb8d1c5dc34b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\promon\resources\views/site/about.blade.php ENDPATH**/ ?>