<?php
    $home = route('site.home');
    // Header: Home plus the sections of the home page (# links).
    $links = [
        ['label' => 'Home', 'href' => $home],
        ['label' => 'About', 'href' => $home . '#about'],
        ['label' => 'Wholesale & Export', 'href' => $home . '#services'],
        ['label' => 'How it works', 'href' => $home . '#how'],
        ['label' => 'Payment', 'href' => $home . '#payment'],
    ];
    // Footer: About and Products on the home page, plus every separate page.
    $footerLinks = [
        ['label' => 'About', 'href' => $home . '#about'],
        ['label' => 'Contact', 'href' => route('site.contact')],
        ['label' => 'Reviews', 'href' => route('site.reviews')],
        ['label' => 'Products', 'href' => $home . '#products'],
        ['label' => 'FAQ', 'href' => route('site.faq')],
    ];
    $pageTitle = $title !== '' ? $title . ' | ' . $company : $company . ' | UK Products to Bangladesh';
    $waUrl = strlen($waDigits) >= 8 ? 'https://wa.me/' . $waDigits : null;
?>
<!DOCTYPE html>
<html lang="en-GB">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($pageTitle); ?></title>
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($description !== ''): ?>
    <meta name="description" content="<?php echo e($description); ?>">
    <meta property="og:description" content="<?php echo e($description); ?>">
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  <meta property="og:title" content="<?php echo e($pageTitle); ?>">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?php echo e($company); ?>">
  <meta property="og:image" content="<?php echo e(asset('assets/site/img/logo.jpeg')); ?>">
  <meta name="theme-color" content="#071240">
  <link rel="canonical" href="<?php echo e(url()->current()); ?>">
  <link rel="icon" type="image/png" href="<?php echo e(asset('assets/site/img/logo-small.png')); ?>">
  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! (app()->environment('production'))): ?>
    <meta name="robots" content="noindex, nofollow">
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/promon.css')); ?>">
  <script src="<?php echo e(asset('assets/site/js/promon.js')); ?>" defer></script>
</head>
<body>
  <a href="#main" class="skip">Skip to main content</a>

  <header class="site-header">
    <div class="wrap">
      <a href="<?php echo e($home); ?>" class="brand" aria-label="<?php echo e($company); ?> home">
        <img src="<?php echo e(asset('assets/site/img/logo-small.png')); ?>" width="56" height="56" alt="<?php echo e($company); ?> logo">
        <span><b>PROMON LTD</b></span>
      </a>
      <nav class="nav" aria-label="Main">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <a href="<?php echo e($link['href']); ?>"><?php echo e($link['label']); ?></a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <a href="<?php echo e(route('site.enquiry')); ?>" class="btn btn--gold btn--sm" <?php if($nav === 'enquiry'): ?> aria-current="page" <?php endif; ?>>Enquire</a>
      </nav>
      <button type="button" class="menu-btn" data-menu-toggle aria-expanded="false" aria-controls="mobile-menu" aria-label="Menu">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
    </div>
    <nav id="mobile-menu" class="mobile-nav" data-menu aria-label="Mobile">
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <a href="<?php echo e($link['href']); ?>"><?php echo e($link['label']); ?></a>
      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      <a href="<?php echo e(route('site.enquiry')); ?>" style="color: var(--gold-soft)">Enquire</a>
    </nav>
  </header>

  <main id="main"><?php echo e($slot); ?></main>

  <footer class="site-footer">
    <div class="wrap">
      <p class="tag"><?php echo e($company); ?> &middot; <i>Bringing You the Best</i></p>
      <nav class="footer-nav" aria-label="Footer">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $footerLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
          <a href="<?php echo e($link['href']); ?>"><?php echo e($link['label']); ?></a>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
      </nav>
      <small>&copy; <?php echo e(date('Y')); ?> <?php echo e($company); ?> &middot; Quality &middot; Trust &middot; Worldwide Connection</small>
    </div>
  </footer>

  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($waUrl): ?>
    <a href="<?php echo e($waUrl); ?>" class="wa-float" target="_blank" rel="noopener" aria-label="Chat on WhatsApp (opens in a new tab)">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.9 7L4 20l1.2-4.6A8 8 0 1 1 21 12z"/></svg>
    </a>
  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\promon\resources\views/components/site/layout.blade.php ENDPATH**/ ?>